package com.msgquality.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@Table(name = "ops_data_columns")
@JsonIgnoreProperties(ignoreUnknown = true)
public class OPSDataColumn {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "COLUMN_ID")
	Long coulmn_id;
	
	@Column(name = "OPS_VERSION")
	String ops_version;
	
	@Column(name = "COLUMN_NAME")
	String column_name;
	
	@Column(name = "COLUMN_TYPE")
	String column_type;
	
	@Column(name = "RECORD_TYPE")
	String record_type;
	
	@Column(name = "RECORD_TYPE_NAME")
	String recordTypeName;
	
	@Column(name = "START_COLUMN")
	Long start_col;
	
	@Column(name = "END_COLUMN")
	Long end_column;
	
	@Column(name = "CHAR_COUNT")
	Long char_count;
	
	public String getRecordTypeName() {
		return recordTypeName;
	}
	public void setRecordTypeName(String recordTypeName) {
		this.recordTypeName = recordTypeName;
	}

	public Long getCoulmn_id() {
		return coulmn_id;
	}
	public void setCoulmn_id(Long coulmn_id) {
		this.coulmn_id = coulmn_id;
	}
	public String getOps_version() {
		return ops_version;
	}
	public void setOps_version(String ops_version) {
		this.ops_version = ops_version;
	}
	public String getColumn_name() {
		return column_name;
	}
	public void setColumn_name(String column_name) {
		this.column_name = column_name;
	}
	public String getColumn_type() {
		return column_type;
	}
	public void setColumn_type(String column_type) {
		this.column_type = column_type;
	}
	public String getRecord_type() {
		return record_type;
	}
	public void setRecord_type(String record_type) {
		this.record_type = record_type;
	}
	public Long getStart_col() {
		return start_col;
	}
	public void setStart_col(Long start_col) {
		this.start_col = start_col;
	}
	public Long getEnd_column() {
		return end_column;
	}
	public void setEnd_column(Long end_column) {
		this.end_column = end_column;
	}
	
	/** Default constructor*/
	public OPSDataColumn(){
		
	}
	
	/** CONSTRUCTOR FIELDS FOR THIS BEAN*/
	public OPSDataColumn(Long coulmn_id, String ops_version,
			String column_name, String column_type, String record_type,
			Long start_col, Long end_column) {
		super();
		this.coulmn_id = coulmn_id;
		this.ops_version = ops_version;
		this.column_name = column_name;
		this.column_type = column_type;
		this.record_type = record_type;
		this.start_col = start_col;
		this.end_column = end_column;
	}
	public Long getChar_count() {
		return char_count;
	}
	public void setChar_count(Long char_count) {
		this.char_count = char_count;
	}
	

}
