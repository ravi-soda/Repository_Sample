package com.msgquality.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * @deprecated
 * 
 *   need to be removed, not in the requirement
 * 
 * @author Pravin
 *
 */
@Entity
@Table(name = "project_status")
public class ProjectStatus extends BaseObj {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3635094939118290557L;

	@Id
	@Column(name = "project_status_id")
	@GeneratedValue
	private int projectStatusId;

	@Column(name = "project_status")
	private String projectStatus;

	@Column(name = "project_status_desc")
	private String projectStatusDesc;

	public int getProjectStatusId() {
		return projectStatusId;
	}

	public void setProjectStatusId(int projectStatusId) {
		this.projectStatusId = projectStatusId;
	}

	public String getProjectStatus() {
		return projectStatus;
	}

	public void setProjectStatus(String projectStatus) {
		this.projectStatus = projectStatus;
	}

	public String getProjectStatusDesc() {
		return projectStatusDesc;
	}

	public void setProjectStatusDesc(String projectStatusDesc) {
		this.projectStatusDesc = projectStatusDesc;
	}

}
