package com.msgquality.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * FileEntry will hold the file and its basic informations. File may be anything
 * like flat file, text or xml etc..
 * 
 * @author Pravin
 *
 */

@Entity
@Table(name = "FILE_ENTRY")
public class FileEntry {

	@Id
	@SequenceGenerator(name="FileEntryIdSeq", sequenceName="SEQ_FILE_ENTRY_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="FileEntryIdSeq")
	@Column(name = "ID")
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.MERGE })
	@JoinColumn(name = "RULE_SET_ID")
	private RuleSet ruleSet;

	@Column(name = "FILE_NAME")
	private String fileName;

	@Column(name = "FILE_TYPE")
	private String fileType;

	@Lob
	@Column(name = "FILE_BLOB")
	private byte[] file_blob;

	@Column(name = "FILE_LOCATION")
	private String fileLocation;

	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "fileEntry")
	private List<FileExecutionResult> fileResults = new ArrayList<FileExecutionResult>();

	public FileEntry() {
	}

	public FileEntry(RuleSet ruleSet, String fileName, String fileType, byte[] file_blob, String fileLocation) {
		this.ruleSet = ruleSet;
		this.fileName = fileName;
		this.fileType = fileType;
		this.file_blob = file_blob;
		this.fileLocation = fileLocation;
	}

	public FileEntry(String fileName, Long id) {
		this.fileName = fileName;
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public RuleSet getRuleSet() {
		return ruleSet;
	}

	public void setRuleSet(RuleSet ruleSet) {
		this.ruleSet = ruleSet;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public byte[] getFile_blob() {
		return file_blob;
	}

	public void setFile_blob(byte[] file_blob) {
		this.file_blob = file_blob;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public List<FileExecutionResult> getFileResults() {
		return fileResults;
	}

	public void setFileResults(List<FileExecutionResult> fileResults) {
		this.fileResults = fileResults;
	}

}
