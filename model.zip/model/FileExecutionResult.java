package com.msgquality.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This will have the information for the file validation result. one file can
 * have multiple validation entry result like this.
 * 
 * @author Pravin
 *
 */

@Entity
@Table(name = "FILE_EXECUTION_RESULT")
public class FileExecutionResult {

	@Id
	@SequenceGenerator(name="FileExecutionResultIdSeq", sequenceName="SEQ_FILE_EXECUTION_RESULT_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="FileExecutionResultIdSeq")
	@Column(name = "ID")
	private Long id;

	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "FILE_ID")
	private FileEntry fileEntry;
	
	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "DATA_FILE_ID")
	private DataFileEntry dataFileEntry;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "RESULT_GEN_DATE")
	private Date resultGeneration;

	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "executionResult")
	private List<RuleExecutionResult> ruleResults = new ArrayList<RuleExecutionResult>();

	public FileExecutionResult() {

	}

	public FileExecutionResult(FileEntry fileEntry, Date resultGenDate) {
		this.fileEntry = fileEntry;
		this.resultGeneration = resultGenDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	

	public FileEntry getFileEntry() {
		return fileEntry;
	}

	public void setFileEntry(FileEntry fileEntry) {
		this.fileEntry = fileEntry;
	}

	public Date getResultGeneration() {
		return resultGeneration;
	}

	public void setResultGeneration(Date resultGeneration) {
		this.resultGeneration = resultGeneration;
	}

	public List<RuleExecutionResult> getRuleResults() {
		return ruleResults;
	}

	public void setRuleResults(List<RuleExecutionResult> ruleResults) {
		this.ruleResults = ruleResults;
	}

	public DataFileEntry getDataFileEntry() {
		return dataFileEntry;
	}

	public void setDataFileEntry(DataFileEntry dataFileEntry) {
		this.dataFileEntry = dataFileEntry;
	}

}
