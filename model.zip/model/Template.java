package com.msgquality.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Template entity
 * 
 * @author Pravin
 *
 */
@Entity
@Table(name = "TEMPLATE")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Template extends BaseObj {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TemplateIdSeq", sequenceName="SEQ_TEMPLATE_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="TemplateIdSeq")
	@Column(name = "ID")
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.ALL })
	@JoinColumn(name = "PROJECT_ID")
	private Project project;

	@Column(name = "FILE_TYPE")
	private String fileType;

	@Column(name = "TEMPLATE_NAME")
	private String templateName;

	@Column(name = "COL_SEPARATOR")
	private String colSeparator;

	@Column(name = "IS_GLOBAL")
	private Boolean isGlobal;

	@Column(name = "HEADER_ROW_COUNT")
	private Integer headerRowsCount;

	@Column(name = "FOOTER_ROW_COUNT")
	private Integer footerRowsCount;

	@Column(name = "HAS_HEADER_ROWS")
	private Boolean hasHeaderRows;

	@Column(name = "HAS_FOOTER_ROWS")
	private Boolean hasFooterRows;

	@Column(name="ENABLE_DATA_ROLE")
    private Boolean enableDataRole;
	
//	@Column(name="FILE_FORMAT")
//	private String fileFormat;
	
	@Column(name="REPEATED_ELEMENT")
	private String repeatedElement;
	
	@Column(name="REPEATED_ELEMENT_BODY")
	private String repeatedElementBody;
	
	@Column(name="REPEATED_ELEMENT_BODY_XP")
	private String repeatingElementBodyXPath;

	@Column(name="REPEATED_ELEMENT_HEAD")
	private String repeatedElementHead;
	
	@Column(name="REPEATED_ELEMENT_HEAD_XP")
	private String repeatingElementHeadXPath;
	
	@Column(name="REPEATED_ELEMENT_FOOTER")
	private String repeatedElementFooter;
	
	@Column(name="REPEATED_ELEMENT_FOOTER_XP")
	private String repeatingElementFooterXPath;

	@Column(name="DELIMITER_COL_COUNT_BODY")
	private Integer delimiterBodyColCount;

	@Column(name="DELIMITER_COL_COUNT_HEADER")
	private Integer delimiterHeaderColCount;

	@Column(name="DELIMITER_COL_COUNT_FOOTER")
	private Integer delimiterFooterColCount;

	@Column(name="OPS_VERSION")
	private String opsVersion;

	@JsonBackReference
	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "template")
	private List<TemplateDataColumn> columns = new ArrayList<TemplateDataColumn>();

	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "template", fetch=FetchType.LAZY)
	private List<RuleSet> templateRuleSet = new ArrayList<RuleSet>();

	@Transient
	@JsonProperty("ruleSet")
	private RuleSet ruleSet;

	@Transient
	@JsonProperty("headers")
	private List<TemplateDataColumn> headers;

	@Transient
	@JsonProperty("footers")
	private List<TemplateDataColumn> footers;

	@Transient
	@JsonProperty("body")
	private List<TemplateDataColumn> body;
	
	@Transient
	@JsonProperty("dataRuleSet")
	private DataRuleSet dataRuleSet;

	public Template() {

	}

	public Template(Project project, String fileType, String templateName,
			String colSeparator, Boolean isGloabl, Integer footerRowsCount,
			Integer headerRowCount, Boolean hasHeaderRows,
			Boolean hasFooterRows, List<TemplateDataColumn> columns,
			List<RuleSet> templateRuleSet) {
		this.project = project;
		this.fileType = fileType;
		this.templateName = templateName;
		this.colSeparator = colSeparator;
		this.isGlobal = isGloabl;
		this.footerRowsCount = footerRowsCount;
		this.headerRowsCount = headerRowCount;
		this.hasHeaderRows = hasHeaderRows;
		this.hasFooterRows = hasFooterRows;
		this.columns = columns;
		this.templateRuleSet = templateRuleSet;
	}

	public Template(Long id, Project project, String fileType,
			String templateName, String colSeparator, Boolean isGlobal,
			Integer headerRowsCount, Integer footerRowsCount,
			Boolean hasHeaderRows, Boolean hasFooterRows,
			Boolean enableDataRole, String fileFormat, String repeatedElement,
			List<TemplateDataColumn> columns, List<RuleSet> templateRuleSet,
			RuleSet ruleSet, List<TemplateDataColumn> headers,
			List<TemplateDataColumn> footers, List<TemplateDataColumn> body) {
		this.id = id;
		this.project = project;
		this.fileType = fileType;
		this.templateName = templateName;
		this.colSeparator = colSeparator;
		this.isGlobal = isGlobal;
		this.headerRowsCount = headerRowsCount;
		this.footerRowsCount = footerRowsCount;
		this.hasHeaderRows = hasHeaderRows;
		this.hasFooterRows = hasFooterRows;
		this.enableDataRole = enableDataRole;
//		this.fileFormat = fileFormat;
		this.repeatedElement = repeatedElement;
		this.columns = columns;
		this.templateRuleSet = templateRuleSet;
		this.ruleSet = ruleSet;
		this.headers = headers;
		this.footers = footers;
		this.body = body;
	}

	public Template(Project project, String fileType, String templateName,
			String colSeparator, Boolean isGloabl, Integer footerRowsCount,
			Integer headerRowCount, Boolean hasHeaderRows,
			Boolean hasFooterRows, List<TemplateDataColumn> columns,
			List<TemplateDataColumn> headers, List<TemplateDataColumn> footers,
			List<TemplateDataColumn> body, List<RuleSet> templateRuleSet, RuleSet ruleSet) {
		this.project = project;
		this.fileType = fileType;
		this.templateName = templateName;
		this.colSeparator = colSeparator;
		this.isGlobal = isGloabl;
		this.footerRowsCount = footerRowsCount;
		this.headerRowsCount = headerRowCount;
		this.hasHeaderRows = hasHeaderRows;
		this.hasFooterRows = hasFooterRows;
		this.columns = columns;
		this.headers = headers;
		this.footers = footers;
		this.body = body;
		this.templateRuleSet = templateRuleSet;
		this.ruleSet = ruleSet;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getColSeparator() {
		return colSeparator;
	}

	public void setColSeparator(String colSeparator) {
		this.colSeparator = colSeparator;
	}

	public Boolean getIsGlobal() {
		return isGlobal;
	}

	public void setIsGlobal(Boolean isGlobal) {
		this.isGlobal = isGlobal;
	}

	public Integer getHeaderRowsCount() {
		return headerRowsCount;
	}

	public void setHeaderRowsCount(Integer headerRowsCount) {
		this.headerRowsCount = headerRowsCount;
	}

	public Integer getFooterRowsCount() {
		return footerRowsCount;
	}

	public void setFooterRowsCount(Integer footerRowsCount) {
		this.footerRowsCount = footerRowsCount;
	}

	public Integer getDelimiterBodyColCount() {
		return delimiterBodyColCount;
	}

	public void setDelimiterBodyColCount(Integer delimiterBodyColCount) {
		this.delimiterBodyColCount = delimiterBodyColCount;
	}

	public Integer getDelimiterHeaderColCount() {
		return delimiterHeaderColCount;
	}

	public void setDelimiterHeaderColCount(Integer delimiterHeaderColCount) {
		this.delimiterHeaderColCount = delimiterHeaderColCount;
	}

	public Integer getDelimiterFooterColCount() {
		return delimiterFooterColCount;
	}

	public void setDelimiterFooterColCount(Integer delimiterFooterColCount) {
		this.delimiterFooterColCount = delimiterFooterColCount;
	}

	public Boolean getHasHeaderRows() {
		return hasHeaderRows;
	}

	public void setHasHeaderRows(Boolean hasHeaderRows) {
		this.hasHeaderRows = hasHeaderRows;
	}

	public Boolean getHasFooterRows() {
		return hasFooterRows;
	}

	public void setHasFooterRows(Boolean hasFooterRows) {
		this.hasFooterRows = hasFooterRows;
	}

	public List<TemplateDataColumn> getColumns() {
		return columns;
	}

	public void setColumns(List<TemplateDataColumn> columns) {
		this.columns = columns;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public List<TemplateDataColumn> getBody() {
		return body;
	}

	public void setBody(List<TemplateDataColumn> body) {
		this.body = body;
	}

	public List<TemplateDataColumn> getHeaders() {
		return headers;
	}

	public void setHeaders(List<TemplateDataColumn> headers) {
		this.headers = headers;
	}

	public List<TemplateDataColumn> getFooters() {
		return footers;
	}

	public void setFooters(List<TemplateDataColumn> footers) {
		this.footers = footers;
	}

	public List<RuleSet> getTemplateRuleSet() {
		return templateRuleSet;
	}

	public void setTemplateRuleSet(List<RuleSet> templateRuleSet) {
		this.templateRuleSet = templateRuleSet;
	}

	public RuleSet getRuleSet() {
		return ruleSet;
	}

	public void setRuleSet(RuleSet ruleSet) {
		this.ruleSet = ruleSet;
	}
	public Boolean getEnableDataRole() {
		return enableDataRole;
	}

	public void setEnableDataRole(Boolean enableDataRole) {
		this.enableDataRole = enableDataRole;
	}

//	public String getFileFormat() {
//		return fileFormat;
//	}
//
//	public void setFileFormat(String fileFormat) {
//		this.fileFormat = fileFormat;
//	}

	public String getRepeatedElement() {
		return repeatedElement;
	}

	public void setRepeatedElement(String repeatedElement) {
		this.repeatedElement = repeatedElement;
	}

	public String getRepeatedElementBody() {
		return repeatedElementBody;
	}

	public void setRepeatedElementBody(String repeatedElementBody) {
		this.repeatedElementBody = repeatedElementBody;
	}

	public String getRepeatingElementBodyXPath() {
		return repeatingElementBodyXPath;
	}

	public void setRepeatingElementBodyXPath(String repeatingElementBodyXPath) {
		this.repeatingElementBodyXPath = repeatingElementBodyXPath;
	}

	public String getRepeatedElementHead() {
		return repeatedElementHead;
	}

	public void setRepeatedElementHead(String repeatedElementHead) {
		this.repeatedElementHead = repeatedElementHead;
	}

	public String getRepeatingElementHeadXPath() {
		return repeatingElementHeadXPath;
	}

	public void setRepeatingElementHeadXPath(String repeatingElementHeadXPath) {
		this.repeatingElementHeadXPath = repeatingElementHeadXPath;
	}

	public String getRepeatedElementFooter() {
		return repeatedElementFooter;
	}

	public void setRepeatedElementFooter(String repeatedElementFooter) {
		this.repeatedElementFooter = repeatedElementFooter;
	}

	public String getRepeatingElementFooterXPath() {
		return repeatingElementFooterXPath;
	}

	public void setRepeatingElementFooterXPath(String repeatingElementFooterXPath) {
		this.repeatingElementFooterXPath = repeatingElementFooterXPath;
	}

	public DataRuleSet getDataRuleSet() {
		return dataRuleSet;
	}

	public void setDataRuleSet(DataRuleSet dataRuleSet) {
		this.dataRuleSet = dataRuleSet;
	}

	public String getOpsVersion() {
		return opsVersion;
	}

	public void setOpsVersion(String opsVersion) {
		this.opsVersion = opsVersion;
	}

	
}
