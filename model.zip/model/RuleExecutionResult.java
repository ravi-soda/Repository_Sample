package com.msgquality.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * 
 * This will track every rules executed over the file like whether it has passed
 * or failed. this will capture whole rule information because in future there
 * may be change on existing rule.
 * 
 * @author Pravin
 *
 */

@Entity
@Table(name = "RULE_EXECUTION_RESULT")
public class RuleExecutionResult {

	@Id
	@SequenceGenerator(name="RuleExecutionResultIdSeq", sequenceName="SEQ_RULE_EXECUTION_RESULT_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="RuleExecutionResultIdSeq")
	@Column(name = "ID")
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.ALL })
	@JoinColumn(name = "FILE_EXECUTION_ID")
	private FileExecutionResult executionResult;

	@Column(name = "RULE_POSITION")
	private Integer rulePosition;

	@Column(name = "RULE_NAME")
	private String ruleName;

	@Column(name = "RULE_DESC")
	private String ruleDesc;

	@Column(name = "RESULT")
	private Boolean result;

	@OneToMany(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY, mappedBy = "ruleExecutionResult")
	private List<FailedRowInfo> failedRows = new ArrayList<FailedRowInfo>();

	public RuleExecutionResult() {

	}

	public RuleExecutionResult(FileExecutionResult executionResult,
			Integer rulePosition, String ruleName, String ruleDesc,
			Boolean result) {
		this.executionResult = executionResult;
		this.rulePosition = rulePosition;
		this.ruleName = ruleName;
		this.ruleDesc = ruleDesc;
		this.result = result;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public FileExecutionResult getExecutionResult() {
		return executionResult;
	}

	public void setExecutionResult(FileExecutionResult executionResult) {
		this.executionResult = executionResult;
	}

	public Integer getRulePosition() {
		return rulePosition;
	}

	public void setRulePosition(Integer rulePosition) {
		this.rulePosition = rulePosition;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getRuleDesc() {
		return ruleDesc;
	}

	public void setRuleDesc(String ruleDesc) {
		this.ruleDesc = ruleDesc;
	}

	public Boolean getResult() {
		return result;
	}

	public void setResult(Boolean result) {
		this.result = result;
	}

	public List<FailedRowInfo> getFailedRows() {
		return failedRows;
	}

	public void setFailedRows(List<FailedRowInfo> failedRows) {
		this.failedRows = failedRows;
	}

}
