package com.msgquality.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * @deprecated
 *  
 *    need to be removed, not in the requirement
 * 
 * @author Pravin
 *
 */
@Entity
@Table(name = "access_privilege")
public class AccessPrivilege extends BaseObj {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1875507207017072298L;

	@Id
	@GeneratedValue
	@Column(name = "access_privilege_id")
	private long privilegeId;

	@Column(name = "access_privilege")
	private String accessPrivilege;

	@Column(name = "access_privilege_desc")
	private String privilegeDesc;

	public long getPrivilegeId() {
		return privilegeId;
	}

	public void setPrivilegeId(long privilegeId) {
		this.privilegeId = privilegeId;
	}

	public String getAccessPrivilege() {
		return accessPrivilege;
	}

	public void setAccessPrivilege(String accessPrivilege) {
		this.accessPrivilege = accessPrivilege;
	}

	public String getPrivilegeDesc() {
		return privilegeDesc;
	}

	public void setPrivilegeDesc(String privilegeDesc) {
		this.privilegeDesc = privilegeDesc;
	}

}
