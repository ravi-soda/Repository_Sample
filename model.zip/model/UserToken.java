package com.msgquality.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "usertoken")
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserToken implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="UserTokenIdSeq", sequenceName="SEQ_USERTOKEN_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="UserTokenIdSeq")
	@Column(name = "USERTOKENID")
	private Long UserTokenId;
	
	public Long getUserTokenId() {
		return UserTokenId;
	}

	public void setUserTokenId(Long userTokenId) {
		UserTokenId = userTokenId;
	}

    @Column(name ="usertoken")
	private String UserToken;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "lastUsed")
    private Date lastUsed;
	
	@Column(name = "active")
    private boolean active;
	@Column(name = "user_id")
	private long userId;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getUserToken() {
		return UserToken;
	}

	public void setUserToken(String userToken) {
		UserToken = userToken;
	}

	public Date getLastUsed() {
		return lastUsed;
	}

	public void setLastUsed(Date lastUsed) {
		this.lastUsed = lastUsed;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}
}
