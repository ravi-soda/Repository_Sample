package com.msgquality.model;

public enum LOVContants {

	DATA_TYPE(1L), RULE_SET_RULE(2L), ROW_POSITION(10L);

	private Long val;

	public Long getVal() {
		return val;
	}

	public void setVal(Long val) {
		this.val = val;
	}

	private LOVContants(Long val) {
		this.val = val;
	}

	public enum RowPosition {
		HEADER(11), FOOTER(13), BODY(12);

		private int id;

		RowPosition(int id) {
			this.id = id;
		}

		public int getId() {
			return id;
		}
	}

}
