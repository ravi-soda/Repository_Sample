package com.msgquality.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * CustomRuleSetParam will hold the custom parameter contents for a rule. It may
 * be a block of JavaScript code or SQL Query etc..,
 * 
 * @author Pravin
 *
 */
@Entity
@Table(name = "CUSTOM_RULESET_PARAM")
public class CustomRuleSetParam {

	@Id
	@SequenceGenerator(name="CustomRuleSetParamIdSeq", sequenceName="SEQ_CUSTOM_RULESET_PARAM_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="CustomRuleSetParamIdSeq")
	@Column(name = "ID")
	private Long id;

	@ManyToOne(cascade = { CascadeType.MERGE, CascadeType.PERSIST,
			CascadeType.REFRESH }, fetch = FetchType.LAZY)
	@JoinColumn(name = "RULE_SET_ID")
	private RuleSet ruleSet;

	@Column(name = "PARAM_ORDER")
	private Integer order;

	@Column(name = "PARAM_TYPE")
	private Integer type;

	@Column(name = "PARAM_KEY")
	private String key;

	@Column(name = "PARAM_VALUE")
	private String value;

	public CustomRuleSetParam() {
	}

	public CustomRuleSetParam(RuleSet ruleSet, Integer order, Integer type,
			String key, String value) {
		this.ruleSet = ruleSet;
		this.order = order;
		this.type = type;
		this.key = key;
		this.value = value;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public RuleSet getRuleSet() {
		return ruleSet;
	}

	public void setRuleSet(RuleSet ruleSet) {
		this.ruleSet = ruleSet;
	}

	public Integer getOrder() {
		return order;
	}

	public void setOrder(Integer order) {
		this.order = order;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
