package com.msgquality.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

/**
 * MQLOV is a meta table which will be used to maintain all meta data's related
 * to this application.
 * 
 * @author Pravin
 *
 */

@Entity
@Table(name = "MQ_LOV")
public class MQLOV {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long id;

	@Column(name = "LOV_KEY")
	private String lovKey;

	@Column(name = "LOV_VAL")
	private String lovVal;

	@JoinColumn(name = "REF_COLUMN")
	private Long parent;

	public MQLOV() {

	}

	public MQLOV(String lovKey, String lovVal, Long parent) {
		this.lovKey = lovKey;
		this.lovVal = lovVal;
		this.parent = parent;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLovKey() {
		return lovKey;
	}

	public void setLovKey(String lovKey) {
		this.lovKey = lovKey;
	}

	public String getLovVal() {
		return lovVal;
	}

	public void setLovVal(String lovVal) {
		this.lovVal = lovVal;
	}

	public Long getParent() {
		return parent;
	}

	public void setParent(Long parent) {
		this.parent = parent;
	}

}
