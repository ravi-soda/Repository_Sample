package com.msgquality.model.rule;

import java.util.List;

import com.msgquality.model.RuleColumn;

public class ValidationTreeNode {
	private RuleColumn objRuleColumn;
	private ValidationTreeNode objLeftNode;
	private ValidationTreeNode objRightNode;
	private List<ValidationTreeNode> lstValidationTreeNode_FuncParams;

	/**
	 * 
	 * @return strContent
	 */
	public RuleColumn getRuleColumn() {
		return objRuleColumn;
	}
	/**
	 * 
	 * @param objRuleColumn - Current node content
	 */
	public void setContent(RuleColumn objRuleColumn) {
		this.objRuleColumn = objRuleColumn;
	}
	/**
	 * 
	 * @return objLeftNode
	 */
	public ValidationTreeNode getLeftNode() {
		return objLeftNode;
	}
	/**
	 * 
	 * @param objLeftTreeNode - Node that holds left hand side of the tree
	 */
	public void setLeftNode(ValidationTreeNode objLeftTreeNode) {
		this.objLeftNode = objLeftTreeNode;
	}
	/**
	 * 
	 * @return objRightNode
	 */
	public ValidationTreeNode getRightNode() {
		return objRightNode;
	}
	/**
	 * 
	 * @param objRightTreeNode - Node that holds right hand side of the tree
	 */
	public void setRightNode(ValidationTreeNode objRightTreeNode) {
		this.objRightNode = objRightTreeNode;
	}
	/**
	 * @return the lstValidationTreeNode
	 */
	public List<ValidationTreeNode> getLstValidationTreeNode_FuncParams() {
		return lstValidationTreeNode_FuncParams;
	}
	/**
	 * @param lstValidationTreeNode_FuncParams the lstValidationTreeNode to set
	 */
	public void setLstValidationTreeNode_FuncParams(List<ValidationTreeNode> lstValidationTreeNode_FuncParams) {
		this.lstValidationTreeNode_FuncParams = lstValidationTreeNode_FuncParams;
	}
}
