package com.msgquality.model.rule;

import java.util.List;

import com.msgquality.model.RuleColumn;
import com.msgquality.model.RuleRow;


public class BoolExprTreeNode {
	private RuleColumn objRuleColumn;
	private int intStartPosition;
	private int intEndPosition;

	private BoolExprTreeNode objLeftNode;
	private BoolExprTreeNode objRightNode;
	private ValidationTreeNode objValidationTreeNode;

	private RuleColumn objConditionalCol; // IF, ELSE_IF, ELSE, END_IF columns are placed in this property - while the current "BoolExprTreeNode" is the root of the entire condition
	private List<ValidationTreeNode> lstBooleanValidationTreeNodes; // System function parameters

	private RuleRow objRuleRow; // Rule row at the root level of the tree - it can be used for display purposes

	public RuleColumn getRuleColumn() {
		return objRuleColumn;
	}
	public void setRuleColumn(RuleColumn objkRuleColumn) {
		this.objRuleColumn = objkRuleColumn;
	}
	public BoolExprTreeNode getLeftNode() {
		return objLeftNode;
	}
	public void setLeftNode(BoolExprTreeNode objLeftTreeNode) {
		this.objLeftNode = objLeftTreeNode;
	}
	public BoolExprTreeNode getRightNode() {
		return objRightNode;
	}
	public void setRightNode(BoolExprTreeNode objRightTreeNode) {
		this.objRightNode = objRightTreeNode;
	}
	public int getStartPosition() {
		return intStartPosition;
	}
	public void setStartPosition(int intStartPosition) {
		this.intStartPosition = intStartPosition;
	}
	public int getEndPosition() {
		return intEndPosition;
	}
	public void setEndPosition(int intEndPosition) {
		this.intEndPosition = intEndPosition;
	}
	public ValidationTreeNode getValidationTreeNode() {
		return objValidationTreeNode;
	}
	public void setValidationTreeNode(ValidationTreeNode objValidationTreeNode) {
		this.objValidationTreeNode = objValidationTreeNode;
	}
	public RuleColumn getConditionalCol() {
		return objConditionalCol;
	}
	public void setConditionalCol(RuleColumn objConditionalCol) {
		this.objConditionalCol = objConditionalCol;
	}
//	Rule row at the root level of the tree - it can be used for display purposes
	public RuleRow getRuleRow() {
		return objRuleRow;
	}
	public void setRuleRow(RuleRow objRuleRow) {
		this.objRuleRow = objRuleRow;
	}
	public List<ValidationTreeNode> getBooleanFuncParams() {
		return lstBooleanValidationTreeNodes;
	}
	public void setBooleanFuncParams(List<ValidationTreeNode> lstBooleanValidationTreeNodes) {
		this.lstBooleanValidationTreeNodes = lstBooleanValidationTreeNodes;
	}
}
