package com.msgquality.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * RuleRow will hold a single rule. it has n number of expression which will be
 * captured using RuleColumn.
 * 
 * @author Pravin
 *
 */

@Entity
@Table(name = "RULE_ROW")
@JsonIgnoreProperties(value={"isSystemGenerated"})
public class RuleRow {

	@Id
	@SequenceGenerator(name="RuleRowIdSeq", sequenceName="SEQ_RULE_ROW_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="RuleRowIdSeq")
	@Column(name = "ID")
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.PERSIST,
			CascadeType.MERGE, CascadeType.REFRESH })
	@JoinColumn(name = "RULE_SET_ID")
	private RuleSet ruleSet;

	@Column(name = "RULE_POSITION")
	private Integer rulePosition;

	@Column(name = "RULE_NAME")
	private String ruleName;

	@Column(name = "RULE_ORDER")
	private Integer order;

	/**
	 * this column is used to maintain the row condition by default it will be
	 * none, but it can have the value available in the
	 * {@link ConditionalStatement}.
	 */
	/*
	 * @Column(name = "row_conditon", columnDefinition = "int default 0")
	 */
	@Transient
	private Integer rowConditon = 0;

	@OneToMany(fetch = FetchType.LAZY, cascade = { CascadeType.ALL }, mappedBy = "rule")
	@OrderBy("order ASC")
	private List<RuleColumn> ruleCols = new ArrayList<RuleColumn>();

	public RuleRow() {

	}

	public RuleRow(RuleSet ruleSet, Integer rulePosition, String ruleName,
			Integer order) {
		this.ruleSet = ruleSet;
		this.rulePosition = rulePosition;
		this.ruleName = ruleName;
		this.order = order;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public RuleSet getRuleSet() {
		return ruleSet;
	}

	public void setRuleSet(RuleSet ruleSet) {
		this.ruleSet = ruleSet;
	}

	public Integer getRulePosition() {
		return rulePosition;
	}

	public void setRulePosition(Integer rulePosition) {
		this.rulePosition = rulePosition;
	}

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public Integer getOrder() {
		return order;
	}

	public void setOrder(Integer order) {
		this.order = order;
	}

	public List<RuleColumn> getRuleCols() {
		return ruleCols;
	}

	public void setRuleCols(List<RuleColumn> ruleCols) {
		this.ruleCols = ruleCols;
	}

	public Integer getRowConditon() {
		return rowConditon;
	}

	public void setRowConditon(Integer rowConditon) {
		this.rowConditon = rowConditon;
	}

}
