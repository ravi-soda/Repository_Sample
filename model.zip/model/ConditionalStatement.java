package com.msgquality.model;

public enum ConditionalStatement {

	ID(43), IF(44), ELSE_IF(45), ELSE(46), END_IF(47);

	private int id;

	private ConditionalStatement(int id) {
		this.id = id;
	}

	public int getId() {
		return this.id;
	}
}
