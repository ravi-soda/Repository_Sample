package com.msgquality.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * TemplateDataColumn Rows Entity, which will hold all type of column for a
 * template.
 * 
 * @author Pravin
 *
 */
@Entity
@Table(name = "TEMPLATE_DATA_COLUMN")
@JsonIgnoreProperties(ignoreUnknown = true)
public class TemplateDataColumn implements Cloneable {

	@Id
	@SequenceGenerator(name="TemplateDataColumnIdSeq", sequenceName="SEQ_TEMPLATE_DATA_COLUMNE_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="TemplateDataColumnIdSeq")
	@Column(name = "ID")
	private Long id;

	@JsonIdentityReference
	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.ALL })
	@JoinColumn(name = "TEMPLATE_ID")
	private Template template;

	@Column(name = "ROW_POSITION")
	private Integer rowPosition;    //filedname,type,recordtype,st col,end col

	@Column(name = "COLUMN_NAME")
	private String columnName;

	@Column(name = "COLUMN_TYPE")
	private Long columnType;

	@Column(name="COLUMN_ORDER")
	private Integer colOrder;
	

	@Column(name="COLUMN_XPATH")
	private String colXPath;
	

	@Column(name = "REPEATED_ELEMENT")
	private String repeatedElement;
	
	@Column(name = "XPATH_VALUE")
	private String xPathValue;

	
	public String getRepeatedElement() {
		return repeatedElement;
	}

	public void setRepeatedElement(String repeatedElement) {
		this.repeatedElement = repeatedElement;
	}

	public String getxPathValue() {
		return xPathValue;
	}

	public void setxPathValue(String xPathValue) {
		this.xPathValue = xPathValue;
	}


	public TemplateDataColumn() {

	}

	public TemplateDataColumn(Template template, Integer rowPosition,
			String columnName, Long columnType, Integer colOrder, String repeatedElement, String xPathValue) {
		this.template = template;
		this.rowPosition = rowPosition;
		this.columnName = columnName;
		this.columnType = columnType;
		this.colOrder=colOrder;
		this.repeatedElement= repeatedElement;
		this.xPathValue = xPathValue;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Template getTemplate() {
		return template;
	}

	public void setTemplate(Template template) {
		this.template = template;
	}

	public Integer getRowPosition() {
		return rowPosition;
	}

	public void setRowPosition(Integer rowPosition) {
		this.rowPosition = rowPosition;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public Long getColumnType() {
		return columnType;
	}

	public void setColumnType(Long columnType) {
		this.columnType = columnType;
	}

	public Integer getColOrder() {
		return colOrder;
	}

	public void setColOrder(Integer colOrder) {
		this.colOrder = colOrder;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		TemplateDataColumn col=new TemplateDataColumn();
		col.setColOrder(colOrder);
		col.setColumnName(columnName);
		col.setColumnType(columnType);
		col.setRowPosition(rowPosition);
		col.setTemplate(template);
		return col;
	}

	public String getColXPath() {
		return colXPath;
	}

	public void setColXPath(String colXPath) {
		this.colXPath = colXPath;
	}
	
}
