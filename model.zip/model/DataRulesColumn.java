package com.msgquality.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "DATA_RULES_COLUMN")
@JsonIgnoreProperties(ignoreUnknown = true)
public class DataRulesColumn  
{
	@Id
	@SequenceGenerator(name="DataRulesColumnSeq", sequenceName="SEQ_DATA_RULES_COLUMN_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="DataRulesColumnSeq")
	@Column(name = "ID")
	private Long id;
	
	@JsonIdentityReference
	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.ALL })
	@JoinColumn(name = "DATA_RULE_ROW_ID", nullable = false)
	private DataRuleRow dataRuleRow;
		
	@Column(name = "COLUMN_POSITION")
	private Integer columnPosition;    

	@Column(name = "RHS_COLUMN_CONTENT")
	private String rhsColumnContent;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public DataRuleRow getDataRuleRow() {
		return dataRuleRow;
	}

	public void setDataRuleRow(DataRuleRow dataRuleRow) {
		this.dataRuleRow = dataRuleRow;
	}

	public Integer getColumnPosition() {
		return columnPosition;
	}

	public void setColumnPosition(Integer columnPosition) {
		this.columnPosition = columnPosition;
	}

	public String getRhsColumnContent() {
		return rhsColumnContent;
	}

	public void setRhsColumnContent(String rhsColumnContent) {
		this.rhsColumnContent = rhsColumnContent;
	}

	
	
	

}
