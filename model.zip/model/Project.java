package com.msgquality.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "project")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Project extends BaseObj {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4915656432065820919L;

	@Id
	@SequenceGenerator(name="ProjectIdSeq", sequenceName="SEQ_project_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="ProjectIdSeq")
	@Column(name = "project_id")
	private long projectId;

	@Column(name = "project_name", unique = true)
	private String projectName;

	@Column(name = "project_desc")
	private String projectDesc;

	@ManyToOne
	@JoinColumn(name = "owner")
	private User owner;

	@OneToMany(mappedBy = "project", fetch=FetchType.LAZY, cascade={CascadeType.ALL})
	private List<Template> projectTemplates = new ArrayList<Template>();

	public long getProjectId() {
		return projectId;
	}

	public void setProjectId(long projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProjectDesc() {
		return projectDesc;
	}

	public void setProjectDesc(String projectDesc) {
		this.projectDesc = projectDesc;
	}

	public User getOwner() {
		return owner;
	}

	public void setOwner(User owner) {
		this.owner = owner;
	}

	public List<Template> getProjectTemplates() {
		return projectTemplates;
	}

	public void setProjectTemplates(List<Template> projectTemplates) {
		this.projectTemplates = projectTemplates;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
