package com.msgquality.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "PROJECT_USER")
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProjectUser extends BaseObj {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5412380741453953569L;

	@Id
	@SequenceGenerator(name="ProjectUserIdSeq", sequenceName="SEQ_PROJECT_USER_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="ProjectUserIdSeq")
	@Column(name = "id")
	private long projectUserId;

	@ManyToOne
	@JoinColumn(name = "project_id")
	private Project projectId;

	@ManyToOne
	@JoinColumn(name = "project_user")
	private User projectUser;

	@Column(name = "is_admin")
	private Boolean isAdmin;

	public long getProjectUserId() {
		return projectUserId;
	}

	public void setProjectUserId(long projectUserId) {
		this.projectUserId = projectUserId;
	}

	public Project getProjectId() {
		return projectId;
	}

	public void setProjectId(Project projectId) {
		this.projectId = projectId;
	}

	public User getProjectUser() {
		return projectUser;
	}

	public void setProjectUser(User projectUser) {
		this.projectUser = projectUser;
	}

	public Boolean isAdmin() {
		return isAdmin;
	}

	public void setAdmin(Boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

}
