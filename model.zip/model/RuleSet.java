package com.msgquality.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Ruleset Entity will hold the different types of rule for a template. <br>
 * <strong>Note:</strong> In UI the template has only one role but the real
 * mapping on db side will be OneToMany.
 * 
 * @author Pravin
 *
 */
@Entity
@Table(name = "RULE_SET")
public class RuleSet extends BaseObj {

	private static final long serialVersionUID = -2611920517881512297L;

	@Id
	@SequenceGenerator(name="RuleSetIdSeq", sequenceName="SEQ_RULE_SET_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="RuleSetIdSeq")
	@Column(name = "ID")
	private Long id;

	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "TEMPLATE_ID")
	private Template template;

	@OneToMany(mappedBy = "ruleSet", cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	private List<CustomRuleSetParam> customRuleSetParameters = new ArrayList<CustomRuleSetParam>();
	
	@OneToMany(mappedBy = "ruleSet", cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	private List<DataFileEntry> dataFileEntries = new ArrayList<DataFileEntry>();

	@OneToMany(mappedBy = "ruleSet", cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	private List<FileEntry> fileEntries = new ArrayList<FileEntry>();

	@OneToMany(mappedBy = "ruleSet", cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@OrderBy("order ASC")
	private List<RuleRow> rules = new ArrayList<RuleRow>();

	@Transient
	@JsonProperty("bodyRules")
	private List<RuleRow> bodyRules = new ArrayList<RuleRow>();

	@Transient
	@JsonProperty("headerRules")
	private List<RuleRow> headerRules = new ArrayList<RuleRow>();

	@Transient
	@JsonProperty("footerRules")
	private List<RuleRow> footerRules = new ArrayList<RuleRow>();

	public RuleSet() {
	}

	public RuleSet(Template template) {
		this.template = template;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Template getTemplate() {
		return template;
	}

	public void setTemplate(Template template) {
		this.template = template;
	}

	public List<CustomRuleSetParam> getCustomRuleSetParameters() {
		return customRuleSetParameters;
	}

	public void setCustomRuleSetParameters(
			List<CustomRuleSetParam> customRuleSetParameters) {
		this.customRuleSetParameters = customRuleSetParameters;
	}

	public List<FileEntry> getFileEntries() {
		return fileEntries;
	}

	public void setFileEntries(List<FileEntry> fileEntries) {
		this.fileEntries = fileEntries;
	}
	
	public List<DataFileEntry> getDataFileEntries() {
		return dataFileEntries;
	}

	public void setDataFileEntries(List<DataFileEntry> dataFileEntries) {
		this.dataFileEntries = dataFileEntries;
	}
	
	

	public List<RuleRow> getRules() {
		return rules;
	}

	public void setRules(List<RuleRow> rules) {
		this.rules = rules;
	}

	public List<RuleRow> getBodyRules() {
		return bodyRules;
	}

	public void setBodyRules(List<RuleRow> bodyRules) {
		this.bodyRules = bodyRules;
	}

	public List<RuleRow> getHeaderRules() {
		return headerRules;
	}

	public void setHeaderRules(List<RuleRow> headerRules) {
		this.headerRules = headerRules;
	}

	public List<RuleRow> getFooterRules() {
		return footerRules;
	}

	public void setFooterRules(List<RuleRow> footerRules) {
		this.footerRules = footerRules;
	}

}
