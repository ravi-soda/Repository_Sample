package com.msgquality.model;

import java.io.IOException;
import java.sql.SQLException;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.msgquality.utils.Constants;

@Entity
@Table(name = "FILE_VALIDATION_DETAILS")
public class FileValidationDetails {
	@Id
	@SequenceGenerator(name="FileValidationDetailsIdSeq", sequenceName="SEQ_FILE_VALIDATION_DETAILS_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="FileValidationDetailsIdSeq")
	@Column(name = "ID")
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.MERGE })
	@JoinColumn(name = "FILE_VALIDATION_SUMMARY_ID")
	FileValidationSummary fileValidationSummary;

	@Column(name = "RULE")
	String rule;

	@Lob
	@Column(name = "COMMENT_BLOB")
	private byte[] comment;

	@Column(name = "RULE_EXEC_STATUS")
	private boolean status;

	@Transient
	@JsonProperty("commentText")
	String commentText;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public FileValidationSummary getFileValidationSummary() {
		return fileValidationSummary;
	}

	public void setFileValidationSummary(
			FileValidationSummary fileValidationSummary) {
		this.fileValidationSummary = fileValidationSummary;
	}

	public String getRule() {
		return rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}

	public byte[] getComment() {
		return comment;
	}

	public void setComment(byte[] comment) {
		this.comment = comment;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getCommentText() {
		return commentText;
	}

	public void setCommentText(String commentText) {
		this.commentText = commentText;
	}

	public void appendComment(String strNewComment, String strFileType) throws SQLException, IOException {
		byte[] blobComment = getComment();
		StringBuffer strComment;
		strComment = getStringBufferForByte(blobComment);
		if (null == strComment || strComment.length() == 0) {
			if (null != strFileType && Constants.FILE_TYPE_XML.equals(strFileType))
				strComment.append("Failed Element # ");
			else
				strComment.append("Failed Row # ");
		}
		else
			strComment.append(", ");
		strComment.append(strNewComment);
//		strComment.append(Constants.BREAK_CHARACTER_HTML + strNewComment);
//		blobComment = getBlobForStringBuffer(strComment);
		setComment(strComment.toString().getBytes());
	}
	/*public static Blob getBlobForStringBuffer(StringBuffer strBuffer) throws SerialException, SQLException {
		SerialBlob objBlob = null;
		// Converting Comment into Byte, then Blob
		if (null != strBuffer) {
			byte[] byteCommentInByte = strBuffer.toString().getBytes();
			try {
				objBlob = new SerialBlob(byteCommentInByte);
			} catch (SerialException e) {
				throw e;
			} catch (SQLException e) {
				throw e;
			}
		}
	    return objBlob;
	}*/
	/*public static StringBuffer getStringBufferForBlob(Blob objBlob) throws SQLException, IOException {
		StringBuffer strComment = new StringBuffer();
		if (null != objBlob) {
			BufferedReader br = new BufferedReader(new InputStreamReader(objBlob.getBinaryStream()));
			String strTemp;
			while ((strTemp=br.readLine())!=null)
				strComment.append(strTemp).append("\n");
	 	}
		return strComment;
	}*/
	public static StringBuffer getStringBufferForByte(byte[] objBlob) throws SQLException, IOException {
		StringBuffer strComment = new StringBuffer();
		if (null != objBlob)
			strComment.append(new String(objBlob, "UTF-8"));
		return strComment;
	}
}
