package com.msgquality.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * RuleRow will hold a single rule. it has n number of expression which will be
 * captured using RuleColumn.
 * 
 * @author Pravin
 *
 */

@Entity
@Table(name = "DATA_RULES_ROW")
@JsonIgnoreProperties(value = { "isSystemGenerated" })
public class DataRuleRow {

	@Id
	@SequenceGenerator(name="DataRuleRowSeq", sequenceName="SEQ_DATA_RULES_ROW_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="DataRuleRowSeq")
	@Column(name = "ID")
	private Long id;

	@ManyToOne(cascade = { CascadeType.PERSIST,
			CascadeType.MERGE, CascadeType.REFRESH }, fetch = FetchType.LAZY)
	@JoinColumn(name = "DATA_RULE_SET_ID", nullable = false)
	private DataRuleSet dataRuleSet;

	@Column(name = "DEST_TEMPLATE_COLUMN_LHS")
	private String templateDataColumnLhs;

	@Column(name = "RULE_POSITION")
	private Integer rulePosition;

	@Column(name = "RULE_ORDER")
	private Integer order;

	@OneToMany(fetch = FetchType.LAZY, cascade = { CascadeType.ALL }, mappedBy = "dataRuleRow")
	@OrderBy("order ASC")
	private List<DataRulesColumn> ruleColsRHS = new ArrayList<DataRulesColumn>();

	public DataRuleRow() {

	}

	public DataRuleSet getDataRuleSet() {
		return dataRuleSet;
	}

	public void setDataRuleSet(DataRuleSet dataRuleSet) {
		this.dataRuleSet = dataRuleSet;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<DataRulesColumn> getRuleColsRHS() {
		return ruleColsRHS;
	}

	public void setRuleColsRHS(List<DataRulesColumn> ruleColsRHS) {
		this.ruleColsRHS = ruleColsRHS;
	}

	public String getTemplateDataColumnLhs() {
		return templateDataColumnLhs;
	}

	public void setTemplateDataColumnLhs(String templateDataColumnLhs) {
		this.templateDataColumnLhs = templateDataColumnLhs;
	}

	public Integer getRulePosition() {
		return rulePosition;
	}

	public void setRulePosition(Integer rulePosition) {
		this.rulePosition = rulePosition;
	}

	public Integer getOrder() {
		return order;
	}

	public void setOrder(Integer order) {
		this.order = order;
	}

}
