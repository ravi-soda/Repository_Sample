package com.msgquality.model;

public class OPSTemplateDataColumn extends TemplateDataColumn {

	private Long charCount;
	private Long startCol;
	private Long endCol;
	private String recordType;
	public Long getCharCount() {
		return charCount;
	}
	public void setCharCount(Long charCount) {
		this.charCount = charCount;
	}
	public Long getStartCol() {
		return startCol;
	}
	public void setStartCol(Long startCol) {
		this.startCol = startCol;
	}
	public Long getEndCol() {
		return endCol;
	}
	public void setEndCol(Long endCol) {
		this.endCol = endCol;
	}
	public String getRecordType() {
		return recordType;
	}
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	
	
}
