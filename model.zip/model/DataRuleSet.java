package com.msgquality.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * DataRuleset Entity will hold the different types of rule for a template. <br>
 * <strong>Note:</strong> In UI the template has only one role but the real
 * mapping on db side will be OneToMany.
 * 
 * @author Pravin
 *
 */
@Entity
@Table(name = "DATA_RULE_SET")
public class DataRuleSet {

	@Id
	@SequenceGenerator(name="DataRuleSetIdSeq", sequenceName="SEQ_DATA_RULE_SET_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="DataRuleSetIdSeq")
	@Column(name = "ID")
	private Long id;

	//@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	//@JoinColumn(name = "TEMPLATE_ID")
	//private Template template;
	
	@ManyToOne(cascade = { CascadeType.PERSIST}, fetch = FetchType.LAZY)
	@JoinColumn(name = "SOURCE_TEMPLATE_ID")
	private Template sourceTemplate;
	
	@ManyToOne(cascade = { CascadeType.PERSIST  }, fetch = FetchType.LAZY)
	@JoinColumn(name = "DEST_TEMPLATE_ID")
	private Template destinationTemplate;

	@OneToMany(mappedBy = "dataRuleSet", cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	private List<DataCustomRuleSetParam> datacustomRuleSetParameters = new ArrayList<DataCustomRuleSetParam>();

//	@OneToMany(mappedBy = "ruleSet", cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
//	private List<DataFileEntry> fileEntries = new ArrayList<DataFileEntry>();

	public List<DataCustomRuleSetParam> getDatacustomRuleSetParameters() {
		return datacustomRuleSetParameters;
	}

	public void setDatacustomRuleSetParameters(
			List<DataCustomRuleSetParam> datacustomRuleSetParameters) {
		this.datacustomRuleSetParameters = datacustomRuleSetParameters;
	}

	@OneToMany(mappedBy = "dataRuleSet", cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	private List<DataRuleRow> rules = new ArrayList<DataRuleRow>();

	@Transient
	@JsonProperty("bodyRules")
	private List<DataRuleRow> bodyRules = new ArrayList<DataRuleRow>();

	@Transient
	@JsonProperty("headerRules")
	private List<DataRuleRow> headerRules = new ArrayList<DataRuleRow>();

	@Transient
	@JsonProperty("footerRules")
	private List<DataRuleRow> footerRules = new ArrayList<DataRuleRow>();

	public DataRuleSet() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	

	
//	public List<DataFileEntry> getFileEntries() {
//		return fileEntries;
//	}
//
//	public void setFileEntries(List<DataFileEntry> fileEntries) {
//		this.fileEntries = fileEntries;
//	}

	public List<DataRuleRow> getRules() {
		return rules;
	}

	public void setRules(List<DataRuleRow> rules) {
		this.rules = rules;
	}

	public Template getSourceTemplate() {
		return sourceTemplate;
	}

	public void setSourceTemplate(Template sourceTemplate) {
		this.sourceTemplate = sourceTemplate;
	}

	public Template getDestinationTemplate() {
		return destinationTemplate;
	}

	public void setDestinationTemplate(Template destinationTemplate) {
		this.destinationTemplate = destinationTemplate;
	}

	public List<DataRuleRow> getBodyRules() {
		return bodyRules;
	}

	public void setBodyRules(List<DataRuleRow> bodyRules) {
		this.bodyRules = bodyRules;
	}

	public List<DataRuleRow> getHeaderRules() {
		return headerRules;
	}

	public void setHeaderRules(List<DataRuleRow> headerRules) {
		this.headerRules = headerRules;
	}

	public List<DataRuleRow> getFooterRules() {
		return footerRules;
	}

	public void setFooterRules(List<DataRuleRow> footerRules) {
		this.footerRules = footerRules;
	}

	

}
