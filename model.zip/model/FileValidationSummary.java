package com.msgquality.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "FILE_VALIDATION_SUMMARY")
public class FileValidationSummary {

	@Id
	@SequenceGenerator(name="FileValidationSummaryIdSeq", sequenceName="SEQ_FILE_VALIDATION_SUMMARY_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="FileValidationSummaryIdSeq")
	@Column(name = "ID")
	private Long id;

	@Column(name = "FILE_ID")
	private Integer fileId;

	@Column(name = "RULESET_ID")
	private Long rulesetId;

	@Column(name = "VALIDATION_RESULT")
	private String validationResult;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "START_VALIDATE_TIME")
	private Date startValidationTime;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "END_VALIDATE_TIME")
	private Date endValidateTime;

	@Column(name = "USER_NAME")
	private String userName;

	@Transient
	@JsonProperty("fileName")
	String fileName;

	@Transient
	long templateId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getFileId() {
		return fileId;
	}

	public void setFileId(Integer fileId) {
		this.fileId = fileId;
	}

	public Long getRulesetId() {
		return rulesetId;
	}

	public void setRulesetId(Long rulesetId) {
		this.rulesetId = rulesetId;
	}

	public Date getStartValidationTime() {
		return startValidationTime;
	}

	public void setStartValidationTime(Date startValidationTime) {
		this.startValidationTime = startValidationTime;
	}

	public Date getEndValidateTime() {
		return endValidateTime;
	}

	public void setEndValidateTime(Date endValidateTime) {
		this.endValidateTime = endValidateTime;
	}

	public String getValidationResult() {
		return validationResult;
	}

	public void setValidationResult(String validationResult) {
		this.validationResult = validationResult;
	}

	public long getTemplateId() {
		return templateId;
	}

	public void setTemplateId(long templateId) {
		this.templateId = templateId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getTimeTakenToValidate() {
		String strTimeTakenToValidate = "";
		if (null != endValidateTime && null != startValidationTime) {
			Long lngTimeTakenToValidate = (endValidateTime.getTime()-startValidationTime.getTime());
			long diffMillis = lngTimeTakenToValidate % 1000;
			long diffSeconds = (lngTimeTakenToValidate / 1000) % 60;
			long diffMinutes = (lngTimeTakenToValidate / (1000 * 60)) % 60;
			long diffHours = (lngTimeTakenToValidate / (1000 * 60 * 60)) % 24;
			long diffDays = (lngTimeTakenToValidate / (1000 * 60 * 60 * 24));
			if (diffDays > 0)
				strTimeTakenToValidate += diffDays + " Days, ";
			if (diffHours > 0)
				strTimeTakenToValidate += String.format("%02d", diffHours) + ":";
			strTimeTakenToValidate += String.format("%02d", diffMinutes) + ":";
			strTimeTakenToValidate += String.format("%02d", diffSeconds) + ".";
			strTimeTakenToValidate += String.format("%03d", diffMillis);
		}
		return strTimeTakenToValidate;
	}
	public String toString() {
		return id + " : " + fileId + " : " + rulesetId + " : " + validationResult + " : " + startValidationTime + " : " + endValidateTime + " : " + fileName + " : " + templateId + " : " + userName;
	}
}
