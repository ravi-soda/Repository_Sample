package com.msgquality.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * This will capture the line of failure in the data file. FailedRowInfo will be
 * associated with rule so that user can understand like m-th rule has failed on n-th line.
 * 
 * @author Pravin
 *
 */

@Entity
@Table(name = "FAILED_ROW_INFO")
public class FailedRowInfo {

	@Id
	@SequenceGenerator(name="FailedRowInfoIdSeq", sequenceName="SEQ_FAILED_ROW_INFO_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="FailedRowInfoIdSeq")
	@Column(name = "ID")
	private Long id;

	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.LAZY)
	@JoinColumn(name = "RULE_EXECUTION_ID")
	private RuleExecutionResult ruleExecutionResult;

	@Column(name = "ROW_POS_IN_DATA_FILE")
	private Integer rowPositionInDataFile;

	public FailedRowInfo() {
	}

	public FailedRowInfo(RuleExecutionResult ruleExecutionResult,
			Integer rowPositionInDataFile) {
		this.ruleExecutionResult = ruleExecutionResult;
		this.rowPositionInDataFile = rowPositionInDataFile;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public RuleExecutionResult getRuleExecutionResult() {
		return ruleExecutionResult;
	}

	public void setRuleExecutionResult(RuleExecutionResult ruleExecutionResult) {
		this.ruleExecutionResult = ruleExecutionResult;
	}

	public Integer getRowPositionInDataFile() {
		return rowPositionInDataFile;
	}

	public void setRowPositionInDataFile(Integer rowPositionInDataFile) {
		this.rowPositionInDataFile = rowPositionInDataFile;
	}

}
