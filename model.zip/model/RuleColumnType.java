package com.msgquality.model;

public enum RuleColumnType {
	NONE,DATA_COLUMN, RULE_OPERATOR, CUSTOM_DATA, CONDITION_STMT, STRING, FLOAT, INTEGER, SYSTEM_FUNC
}