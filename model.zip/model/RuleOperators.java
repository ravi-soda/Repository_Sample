package com.msgquality.model;

public class RuleOperators {

	public enum ArithmaticOP {
		ID(14), ADD(15), SUB(16), MUL(17), DIV(18), REM(19), INC(20), DEC(21), ASSIGN(
				28);

		private int id;

		private ArithmaticOP(int id) {
			this.id = id;
		}

		public int getId() {
			return id;
		}

	}

	public enum Braces {
		ID(22), OPEN_BRACE(23), CLOSE_BRACE(24), OPEN_BRACKET(25), CLOSE_BRACKET(26), COMA(48);

		private int id;

		private Braces(int id) {
			this.id = id;
		}

		public int getId() {
			return id;
		}

	}

	public enum ComparisonOP {
		ID(27), EQ(29), NE(30), STRICT_EQ(31), GRATER(32), GRATER_EQ(33), LESSER(
				34), LESS_EQ(35);

		private int id;

		private ComparisonOP(int id) {
			this.id = id;
		}

		public int getId() {
			return id;
		}

	}

	public enum LogicalOP {
		ID(36), AND(37), OR(38), NOT(39);

		private int id;

		private LogicalOP(int id) {
			this.id = id;
		}

		public int getId() {
			return id;
		}

	}

	public enum SystemFunctions {
		ID(49), REGEXP(50), LENGTH(51), SUM(52), AVG(53), MAX(54), MIN(55), IN(56), NOTIN(57), ISNULL(58), ISNOTNULL(59), DATE_TOINT(60), DATE_TOSTRING(61), ISVALIDDATE(62);

		private int id;

		private SystemFunctions(int id) {
			this.id = id;
		}

		public int getId() {
			return id;
		}

	}

}
