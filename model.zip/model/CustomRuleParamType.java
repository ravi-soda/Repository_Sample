package com.msgquality.model;

public enum CustomRuleParamType {
	ID(40), MY_SQL(41), JAVA_SCRIPT(42);

	private int id;

	private CustomRuleParamType(int id) {
		this.id = id;
	}

	public int getId() {
		return this.id;
	}
}
