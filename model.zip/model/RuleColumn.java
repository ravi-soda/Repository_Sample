package com.msgquality.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * This will hold the single segment of the every rule expressions. One rule can
 * have n number of columns for a single expression. <br>
 * Example : <code> (a+b)</code> here columns are divided as following <code>
 * <tbody>
 * 	<th><td><b>'('</b> </td><td><b>'a'</b> </td><td><b>'+'</b> </td><td><b>'b'</b> </td><td><b>')'</b></td></th>
 * <tbody>
 * </code>
 * 
 * @author Pravin
 *
 */

@Entity
@Table(name = "RULE_COLUMN")
@JsonIgnoreProperties(ignoreUnknown = true)
public class RuleColumn implements Comparable<RuleColumn> {

	@Id
	@SequenceGenerator(name="RuleColumnIdSeq", sequenceName="SEQ_RULE_COLUMN_ID", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="RuleColumnIdSeq")
	@Column(name = "ID")
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.PERSIST,
			CascadeType.MERGE, CascadeType.REFRESH })
	@JoinColumn(name = "RULE_ID")
	private RuleRow rule;

	@Column(name = "RULE_CONTENT")
	private String ruleContent;

	/**
	 * appropriate column data id, if it is operator, operator id will be
	 * mentioned or if it is a column, column id will be mentioned or if it is a
	 * custom data, custom data is will be mentioned
	 */
	@Column(name = "COL_REF_ID")
	private Long colRefId;

	/**
	 * this is used to identify the column data whether it is a operator or
	 * column or custom data.
	 */
	@Column(name = "COL_TYPE")
	private RuleColumnType columnType;

	@Column(name = "RULE_ORDER")
	private Integer order;

	/**
	 * to store a temporary column options unique id.
	 */
	@Column(name = "COL_OPT_UNIQUE_ID")
	private String colUniqueId;

	public RuleColumn() {
	}

	public RuleColumn(RuleRow rule, String ruleContent, Integer order,
			Long colRefId, RuleColumnType columnType, String colUniqueId) {
		this.rule = rule;
		this.ruleContent = ruleContent;
		this.order = order;
		this.colRefId = colRefId;
		this.columnType = columnType;
		this.colUniqueId = colUniqueId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public RuleRow getRule() {
		return rule;
	}

	public void setRule(RuleRow rule) {
		this.rule = rule;
	}

	public String getRuleContent() {
		return ruleContent;
	}

	public void setRuleContent(String ruleContent) {
		this.ruleContent = ruleContent;
	}

	public Integer getOrder() {
		return order;
	}

	public void setOrder(Integer order) {
		this.order = order;
	}

	public Long getColRefId() {
		return colRefId;
	}

	public void setColRefId(Long colRefId) {
		this.colRefId = colRefId;
	}

	public RuleColumnType getColumnType() {
		return columnType;
	}

	public void setColumnType(RuleColumnType columnType) {
		this.columnType = columnType;
	}

	public String getColUniqueId() {
		return colUniqueId;
	}

	public void setColUniqueId(String colUniqueId) {
		this.colUniqueId = colUniqueId;
	}

	public int compareTo(RuleColumn o) {
		if (this.getOrder() > o.getOrder()) {
			return 1;
		} else if (this.getOrder() < o.getOrder()) {
			return -1;
		}
		return 0;
	}

	public String toString() {
		return ruleContent;
	}
}
